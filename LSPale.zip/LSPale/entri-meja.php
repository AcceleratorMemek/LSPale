<?php 
  $judul = 'MEJA';
  include "header.php";
  include "sidebar.php";
  include "topbar.php"; ?>
<div class="card">
	<div class="card-header">
		<a href="tambah_table.php" class="btn btn-primary btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-plus"></i>
             </span>
             <span class="text">Tambah</span>
        </a>
	</div>
	<div class="card-body">
		 <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nomer Meja</th>
                        <th>Status Meja</th>
                       <th>Edit</th>
                       <th>Hapus</th>
                    </tr>
                </thead>                 
                <tbody>
                <?php
                    include 'koneksi.php';
                    $no = 1;
                    $sql = "SELECT * FROM tbl_meja";
                    $result = mysqli_query($koneksi, $sql);
                    while($data = mysqli_fetch_array($result)){
                ?>

          <tr>
              <td><?php echo $no++;?></td>
              <td><?php echo $data['nomor_meja'];?></td>
              <td><?php echo $data['status_meja'];?></td>
                    <td>
                        <a href="edit_table.php?id_meja=<?= $data['id_meja'] ?>"class="btn btn-success">
                            <i class="fa fa-pen"></i> Edit
                        </a>
                    </td>                          
                    <td>
                        <a onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data')"href="hapus_table.php?id_meja=<?= $data['id_meja'] ?>" class="btn btn-danger">
                            <i class="fa fa-trash"></i> Hapus
                        </a>    
                    </td>
                    <?php }?>      
                </tr>
            </tbody>
            </table>
         </div>
	</div>
</div>
<?php include('footer.php') ?>
