<?php
 $judul = 'EDIT MEJA';
 include "header.php";
 include "sidebar.php";
 include "topbar.php"; 
  ?>
<?php
$id_meja = $_GET['id_meja'];
include 'koneksi.php';
$sql = "SELECT*FROM tbl_meja WHERE id_meja = '$id_meja'";
$query = mysqli_query($koneksi, $sql);
$value = mysqli_fetch_array($query);
?>

<div class="card">
    <div class="card-header">
        <a href="main.php" class="btn btn-success btn-icon-split">
                <span class="icon text-white-50">
                 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
    </div>
    <div class="card-body">
        <form method="POST" action="simpan_edit_table.php">
        <input type="hidden" name="id_meja" value="<?= $id_meja ?>">
            <div class="form-group">
                <label>ID Menu</label>
                <input value="<?= $value['id_meja'] ?>" name="id_meja" class="form-control" type="text" readonly>
            </div>
            <div class="form-group">
                <label>Nomor meja</label>
                <input value="<?= $value['nomor_meja'] ?>" name="nomor_meja" class="form-control" type="text" required>
            </div>
            <div class="form-group">
				<label>Status Meja</label>
				<select value="<?= $value['status_meja'] ?>" name="status_meja" class="form-control" type="text" required>
					<option selected hidden>  </option>	
					<option value="Available">Available</option>
					<option value="Occupied">Occupied</option>
				</select>
			</div>
            <div class="form-group">
                <button type="submit" class="btn btn-success"><i class="fa fa-save"></i>SIMPAN</button>
            </div>
        </form>
    </div>
</div>
<?php include('footer.php') ?>